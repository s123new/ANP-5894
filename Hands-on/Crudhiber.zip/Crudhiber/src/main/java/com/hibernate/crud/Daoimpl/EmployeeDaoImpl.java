package com.hibernate.crud.Daoimpl;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hibernate.crud.Config.HibernateUtil;
import com.hibernate.crud.Dao.EmployeeDao;
import com.hibernate.crud.entity.Employee;

public class EmployeeDaoImpl implements EmployeeDao{
	
	Scanner sc = new Scanner(System.in);

	@Override
	public void addEmp() {
		//System.out.println("In add method");
		
		// Yea do line me problem hail
		//Session session = HibernateUtil.getSessionFactory().openSession();
		//Transaction tx = session.beginTransaction();
		
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		//System.out.println("Sab thik");
		String Name, Surname, Address, Designation;
		long ContactNo;
		int id;
		
		System.out.println(" Enter the ID : ");
		id=sc.nextInt();
		
		System.out.println(" Enter the name : ");
		Name = sc.next();
		
		System.out.println(" Enter the surname : ");
		Surname = sc.next();
		
		System.out.println(" Enter the address : ");
		Address = sc.next();
		
		System.out.println(" Enter the Designation : ");
		Designation = sc.next();
		
		System.out.println(" Enter the phone number : ");
		ContactNo=sc.nextLong();
		
		Employee emp = new Employee();
		emp.setEmpId(id);
		emp.setEmpFirstName(Name);
		emp.setEmpLastName(Surname);
		emp.setEmpAdd(Address);
		emp.setEmpDesig(Designation);
		emp.setEmpPhone(ContactNo);
		
		System.out.println(emp);
		session.save(emp);
		tx.commit();
		session.close();
		
		System.out.println(" Successsss ..........");
							
	}

	/*@Override
	public void deleteEmp() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		System.out.println(" Enter the Employee ID to be deleted : ");
		
	}*/
	@Override
	public void deleteEmp() 
	{
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
	    System.out.println("Enter the employee name to delete: ");
	    int employeeeId= sc.nextInt();
	    Employee empToDelete = session.get(Employee.class, employeeeId);
	    if (empToDelete != null) {
	        session.delete(empToDelete);
	        tx.commit();
	        System.out.println("Employee with ID " + employeeeId + " has been deleted.");
	    } else {
	        System.out.println("Employee with ID " + employeeeId + " not found.");
	    }
	    session.close();
	}

	@Override
	public void editEmp() {
	    Session session = HibernateUtil.getSessionFactory().openSession();
	    Transaction ts = session.beginTransaction();
	   System.out.println("Enter the employee ID to edit: ");
	    int employeeId = sc.nextInt();
	    Employee empToEdit = session.get(Employee.class, employeeId);
	    if (empToEdit != null) {
	        boolean isEditing = true;
	        while (isEditing) {
	            System.out.println("Select the field to edit:");
	            System.out.println("1. First Name");
	            System.out.println("2. Last Name");
	            System.out.println("3. Address");
	            System.out.println("4. Designation");
	            System.out.println("5. Mobile Number");
	            System.out.println("6. Exit");
	            int choice = sc.nextInt();
	            sc.nextLine(); // Consume newline
	            switch (choice) {
	               case 1:
	                    System.out.println("Enter the new first name: ");
	                    String newFirstName = sc.nextLine();
	                    empToEdit.setEmpFirstName(newFirstName);
	                    break;
	                case 2:
	                    System.out.println("Enter the new last name: ");
	                    String newLastName = sc.nextLine();
	                    empToEdit.setEmpFirstName(newLastName);
	                    break;
	                case 3:
	                    System.out.println("Enter the new address: ");
	                    String newAddress = sc.nextLine();
	                    empToEdit.setEmpDesig(newAddress);
	                    break;
	                case 4:
	                	System.out.println("Enter the new designation: ");
	                    String newDesignation = sc.nextLine();
	                    empToEdit.setEmpDesig(newDesignation);
	                    break;
	                case 5:
	                	System.out.println("Enter the new mobile number: ");
	                	long newMobileNumber = sc.nextLong();
	                	empToEdit.setEmpPhone(newMobileNumber); // Corrected variable name
	                    break;
	                case 6:
	                    isEditing = false;
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please select a valid option.");
	                    break;
	            }
	        }
	        session.update(empToEdit);
	        ts.commit();
	        System.out.println("Employee with ID " + employeeId + " has been updated.");
	    } else {
	        System.out.println("Employee with ID " + employeeId + " not found.");
	    }
	    session.close();
	}
	
	
	@Override
	public void displayEmp() 
	{
	    Session session = HibernateUtil.getSessionFactory().openSession();
	    List<Employee> employees = session.createQuery("FROM Employee", Employee.class).list();
	    session.close();
	    System.out.println("Employee List:");
	    for (Employee emp : employees) {
	        System.out.println("First Name: " + emp.getEmpFirstName());
	        System.out.println("Last Name: " + emp.getEmpFirstName());
	        System.out.println("Address: " + emp.getEmpAdd());
	        System.out.println("Designation: " + emp.getEmpDesig());
	        System.out.println("Mobile Number: " + emp.getEmpPhone());
	        System.out.println();
	    }
	}

}

