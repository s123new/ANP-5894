package com.hibernate.crud;

import java.util.Scanner;

//import org.hibernate.Session;
//import org.hibernate.Transaction;

//import com.hibernate.crud.Config.HibernateUtil;
import com.hibernate.crud.Daoimpl.EmployeeDaoImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	EmployeeDaoImpl impl = new EmployeeDaoImpl();
          	
    	char a;
		do
    	{
    		Scanner sc = new Scanner (System.in);
    		System.out.println(" Employee registration ");
    		System.out.println(" 1. Add  2.Display  3. Delete   4.Edit   5.Exit ");
    		System.out.println(" Enter the operation number to be peformed : ");
    		int ch = sc.nextInt();
    		
    		switch(ch)
    		{
    		case 1:
    		{
    			System.out.println("in case 1");
    			impl.addEmp();
    			break;
    		}
    		case 2:
    		{
    			impl.displayEmp();
    			break;
    		}
    		case 3:
    		{
    			impl.deleteEmp();
    			break;
    		}
    		case 4:
    		{
    			impl.editEmp();
    			break;
    		}
    		case 5:
    		
    			System.exit(0);
    			break;
    		}
    		System.out.println(" Do you want to continue Y/N ?");
    		a= sc.next().charAt(0);
    	}
		
    	while(a=='Y'||a=='y');
    	{
    		System.out.println(" Thanks. ");
    	}
    		
    }
}
