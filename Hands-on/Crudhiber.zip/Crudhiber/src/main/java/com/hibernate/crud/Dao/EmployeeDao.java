package com.hibernate.crud.Dao;

public interface EmployeeDao {

	public void addEmp();
	public void deleteEmp();
	public void editEmp();
	public void displayEmp();
	
	
}
