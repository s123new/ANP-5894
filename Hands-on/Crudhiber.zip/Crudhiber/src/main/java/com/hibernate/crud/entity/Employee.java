package com.hibernate.crud.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emp000")
public class Employee {

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int empId;
	@Column(name="Name")
	private String empFirstName;
	@Column(name="Surname")
	private String empLastName;
	@Column(name="ContactNo")
	private long empPhone;
	@Column(name="Address")
	private String empAdd;
	@Column(name="Designation")
	private String empDesig;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int empId, String empFirstName, String empLastName, long empPhone, String empAdd, String empDesig) {
		super();
		this.empId = empId;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empPhone = empPhone;
		this.empAdd = empAdd;
		this.empDesig = empDesig;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpFirstName() {
		return empFirstName;
	}

	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}

	public String getEmpLastName() {
		return empLastName;
	}

	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}

	public long getEmpPhone() {
		return empPhone;
	}

	public void setEmpPhone(long empPhone) {
		this.empPhone = empPhone;
	}

	public String getEmpAdd() {
		return empAdd;
	}

	public void setEmpAdd(String empAdd) {
		this.empAdd = empAdd;
	}

	public String getEmpDesig() {
		return empDesig;
	}

	public void setEmpDesig(String empDesig) {
		this.empDesig = empDesig;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empFirstName=" + empFirstName + ", empLastName=" + empLastName
				+ ", empPhone=" + empPhone + ", empAdd=" + empAdd + ", empDesig=" + empDesig + "]";
	
	}
	
}
